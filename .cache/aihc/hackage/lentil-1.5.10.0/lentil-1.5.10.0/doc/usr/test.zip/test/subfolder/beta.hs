module Beta where

-- TODO: make export list explicit in Beta [lint]

-- TODO: I think constants should
--       not be exposed here, but imported from
--       another package
pi = 3.1415


