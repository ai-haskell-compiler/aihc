module Main where


-- FIXME: add prompt before getline, or the user might complain! [interface]
main = getLine >>= \l ->
       putStrLn (replace "o" "bb" l)


-- Ancillaries --

-- TODO: add a type signature to replace [lint]
-- replace function from http://bluebones.net/2007/01/replace-in-haskell/
replace _ _ [] = []
replace find repl s =
    if take (length find) s == find
        then repl ++ (replace find repl (drop (length find) s))
        else [head s] ++ (replace find repl (tail s))

